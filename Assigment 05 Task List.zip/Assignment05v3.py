# Task Tracker
# Demonstrates using dictionaries
#  read  txt file into dictionary
objF = open("C:\\_PythonClass\\Assignment05\\todo.txt", "r")
d={ }
for line in objF:
    x=line.split(":")
    a=x[0]
    b=x[1]
    c=len(b)-1 # the -1 get len of b  -"\n"
    b=b[0:c]
    d[a]=b
#    print(a,":",b)
dictionary=d
#geek = {"404": "clueless. From the web error message 404, meaning page not found.", "Googling": "searching the Internet for background information on a person.", "Keyboard Plaque" : "the collection of debris found in computer keyboards.", "Link Rot" : "the process by which web page links become obsolete.", "Percussive Maintenance" : "the act of striking an electronic device to make it work.", "Uninstalled" : "being fired. Especially popular during the dot-bomb era."}
#dictionary = {"Clean House" : "Low",
#                "Pay Bills" : "High",
#                "Vacuum" : "Medium",
#                "Have a beer" : "Low"}
choice = None
while choice != "7":
    print(
    """










Task Tracker
1 - List current activities
2 - Look up a task
3 - Add a task
4 - Redefine a task
5 - Delete a task
6 - Save tasks to file
7 - Quit

    """
    )
    choice = input("Choice: ")
    print()
    if choice == "1":
        print(
        """








        """)
        print("********* List of Tasks : Priorities  *********")
        for key, value in dictionary.items():
            print(key, ":", value)
        print("***********************************************")
        print()
        input("Hit <Enter> to continue... ")

        # get a definition
    elif choice == "2":
        term = input("What task do you want to look up?: ")
        if term in dictionary:
            definition = dictionary[term]
            print("\n", term, "has a priority of:", definition)
            print()
        else:
            print("\nSorry, I can't find the task", term)
        input("Hit <Enter> to continue... ")

        # add a term-definition pair
    elif choice == "3":
        term = input("What task do you want me to add?: ")
        if term not in dictionary:
            definition = input("\nWhat's the priority?: ")
            dictionary[term] = definition
            print("\n", term, "has been added.")
        else:
            print("\nThat task already exists! Try re-prioritizing it.")
        print()
        input("Hit <Enter> to continue... ")
     # re-prioritize an existing task
    elif choice == "4":
        term = input("What task do you want me to re-prioritize?: ")
        if term in dictionary:
            definition = input("What's the new priority?: ")
            dictionary[term] = definition
            print("\n", term, "has been re-prioritized to", definition)
        else:
            print("\nThat task doesn't exist! Try adding it.")
        print()
        input("Hit <Enter> to continue... ")

    # delete a task-prioritization pair
    elif choice == "5":
        term = input("What task do you want me to delete?: ")
        if term in dictionary:
            del dictionary[term]
            print("\nOkay, I deleted the task", term)
        else:
            print("\nI can't do that!", term, "doesn't exist in the task list.")
        print()
        input("Hit <Enter> to continue... ")

    elif choice == "6":
        with open("C:\\_PythonClass\\Assignment05\\todo.txt", "w") as fp:
            for key, value in dictionary.items():
#                print(key, ":", value)
                fp.write(key+":"+value+"\n")
            #    fp.write("\n")
        print("Data saved to file!")
        print()
        input("Hit <Enter> to continue... ")
    # exit
    elif choice == "7":
        print("Good-bye. Thank you for using Tasker!")
