#------------------------------------------------------------------
#
# Title: Working with Objects
# Dev:   RRoot
# Date:  Sept 16, 2017
# ChangeLog: (Who, When, What)
#   JPatten, 03/06/2019, This uses classes to add data to a table
#------------------------------------------------------------------

class Product:

    #--Constructor--
    def __init__(self, ID, Name, Price):
      #Attributes
      self.__ID = ID
      self.__Name = Name
      self.__Price = Price

    #Properties
    # ID
    @property  #getter(accessor)
    def ID(self):
      return self.__ID

    @ID.setter  #(mutator)
    def ID(self, Value):
      self.__ID = Value

    #Name
    @property #getter(accessor)
    def Name(self):
      return self.__Name

    @Name.setter #(mutator)
    def Name(self, Value):
      self.Name = Value

    #Price
    @property #getter(accessor)
    def Price(self):
      return self.__Price

    @Price.setter #(mutator)
    def Price(self, Value):
      self.Price = Value

    #Methods
    def __str__(self):
      return str(self.ID) + "," + self.Name + "," + str(self.Price)
#End of Class

class DataProcessing:
    def WriteFileToList(strFile):
        lstProducts = []
        try:
            #  print(message)
            objF = open(strFile, 'r')
            for row in objF:
                lst = row.strip().split(',')
                lstProducts.append(Product(lst[0], lst[1], lst[2]))
        except Exception as e:
            print("Error: " + str(e))
        finally:
            objF.close()
        return lstProducts

    def WriteListToFile(strFile, lstTable):
        try:
            objF = open(strFile, 'w')
            for prod in lstTable:
                objF.write(str(prod) + "\n")
        except Exception as e:
            print("Error: " + str(e))
        return lstTable

#I/O
strFile = 'C:\_PythonClass\Assignment08\Products.txt'
lstCurrentProductData = []

def ShowCurrentDataInList(lstData):
    try:
        print("Here is the current data:")
        for prod in lstData:
            print(prod)
    except Exception as e:
        print(e)
def GetNewData(lstTable):
    try:
        print("\nType in a Product ID, Name and Price you want to add to the file")
        while (True):
            strUserInput = input("Enter Product ID, Name and Price (e.g. 1,bolts,1.29) or  'Exit' to quit:  ")
            if (strUserInput.lower() == "exit"): break
            else:
                lstTemp =  str(strUserInput).strip().split(",")
                objP = Product(lstTemp[0], lstTemp[1], lstTemp[2])
                lstTable.append(objP)
                ShowCurrentDataInList(lstTable)
    except Exception as e:
        print(e)
def AskToSave(lstTable):
    try:
        strAns = input("Save data to file (y/n): ").strip()
        if strAns.lower() == 'y':
            DataProcessing.WriteListToFile(strFile, lstTable)
    except Exception as e:
        print(e)

#Main routine

try:
    # Copy data from file into list
    lstCurrentProductData = DataProcessing.WriteFileToList(strFile)
    # Show data in list
    ShowCurrentDataInList(lstCurrentProductData)
    # Get new data from user input
    GetNewData(lstCurrentProductData)
    # Show data in list
    ShowCurrentDataInList(lstCurrentProductData)
    # As user if the want to save the data in list to file
    AskToSave(lstCurrentProductData)
except FileNotFoundError as e:
    print("Error: " + str(e) + "\n Please check for  the file name")
except Exception as e:
    print("Error: " + str(e))

