#-------------------------------------------------#
# Title: Working with Dictionaries
# Dev:   RRoot
# Date:  Sept 16, 2017
# ChangeLog: (Who, When, What)
#   RRoot, 09/16/2017, Created Script
#   JPatten, 02/13/2019, Modified script to incorporate classes and functions

'''This program maintains a to-do list that utilizes functions
It can list, add, delete tasks and allows the user to save their changes to a file'''

# ---------------------------------------------------------------------------------------
#  Data
# ---------------------------------------------------------------------------------------
# declare variables and constants
objFileName = "C:\_PythonClass\Assignment06\Todo.txt"
lstTable = []
strMsg = ""
strChoice = ""

# ---------------------------------------------------------------------------------------
# Functions in module
# ---------------------------------------------------------------------------------------
class Tasker():
   @staticmethod
   def LoadData(flstTable=lstTable,fobjFileName=objFileName):
       dicRow = {}
       strData = ""
       fobjFile = open(fobjFileName, "r")
       for line in fobjFile:
           strData = line.split(",")  # readline() reads a line of the data into 2 elements
           fdicRow = {"Task": strData[0].strip(), "Priority": strData[1].strip()}
           flstTable.append(fdicRow)
       fobjFile.close()
       return flstTable

   # Display current tasks
   def DisplayCurrentMenu():
       print("""
       Menu of Options
       1) Show current data
       2) Add a new item.
       3) Remove an existing item.
       4) Save Data to File
       5) Exit Program
       """
             )
       return


   def ListTasks(flstTable=lstTable):
       print()
       print("**** The current items in the ToDo are: ****")
       for row in flstTable:
           print(row["Task"] + "(" + row["Priority"] + ")")
       print("********************************************")
       print()
       input("Press any key to continue...")
       return

   # Accept user input
   def GetUserInput(fstrMsg=strMsg,fstrChoice=strChoice):
       fstrChoice = str(input(fstrMsg))
       return fstrChoice

   # Add record
   def AddData(flstTable=lstTable, fobjFileName=objFileName):
       strTask = str(input("What is the task? - ")).strip()
       strPriority = str(input("What is the priority? [high|low] - ")).strip()
       dicRow = {"Task": strTask, "Priority": strPriority}
       flstTable.append(dicRow)
       Tasker.ListTasks(flstTable=flstTable)
       return

   # Delete record
   def DeleteData(flstTable=lstTable):
       strKeyToRemove = input("Which TASK would you like removed? - ")
       blnItemRemoved = False #Creating a boolean Flag
       intRowNumber = 0
       while(intRowNumber < len(flstTable)):
           if(strKeyToRemove == str(list(dict(lstTable[intRowNumber]).values())[0])): #the values function creates a list!
               del flstTable[intRowNumber]
               blnItemRemoved = True
           #end if
           intRowNumber += 1
       #end for loop
       print()
       if(blnItemRemoved == True):
           print("The task was removed.")
       else:
           print("I'm sorry, but I could not find that task.")
       print()
       input("Press any key to continue...")
       Tasker.ListTasks(flstTable)
       return

   def SaveData(fobjFileName,flstTable):
       strTask = ""
       strPriority = ""
       dicRow = {"Task": strTask, "Priority": strPriority}
       objFile = open(objFileName, "w")
       if ("y" == str(input("Are you sure you want to save this data to file? (y/n) - ")).strip().lower()):
           objFile = open(fobjFileName, "w")
           for dicRow in flstTable:
               objFile.write(dicRow["Task"] + "," + dicRow["Priority"] + "\n")
           objFile.close()
           input("Data saved to file! Press the [Enter] key to return to menu.")
       else:
           input("New data was NOT Saved, but previous data still exists! Press the [Enter] key to return to menu.")

# ---------------------------------------------------------------------------------------
# Main routine
# ---------------------------------------------------------------------------------------

# Step 1
# When the program starts, load the any data you have
# in a text file called ToDo.txt into a python Dictionary.
lstTable=Tasker.LoadData(lstTable,objFileName)

while(True):
    # Step 2
    # Display a menu of choices to the user
    Tasker.DisplayCurrentMenu()
    strChoice = str(input("Which option would you like to perform? [1 to 5] - "))
    if (strChoice.strip() == '1'):
        # Step 3
        # Show the current items in the table
        Tasker.ListTasks(lstTable)
    elif(strChoice.strip() == '2'):
        # Step 4
        # Add a new item to the list/Table and show the current items after having added it
        Tasker.AddData(lstTable,objFileName)
    # Step 5
    # Remove a new item to the list/Table
    elif(strChoice == '3'):
        #5a-Allow user to indicate which row to delete
        Tasker.DeleteData(lstTable)
    elif(strChoice == '4'):
        # Step 6
        # Save tasks to the ToDo.txt file
        Tasker.SaveData(fobjFileName=objFileName,flstTable=lstTable)
    elif (strChoice == '5'):
        input("Thanks for using Tasker. Press any key to exit....")
        break #and Exit the program
