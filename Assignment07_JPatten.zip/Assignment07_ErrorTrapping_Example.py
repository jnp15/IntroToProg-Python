#----------------------------------------------------------------------#
# Title: Error Handling Script
# Dev: JPatten
# Date Feb 22, 2019
# ChangeLog:
# Purpose:  This program demonstrates how do error handling.
#    In this example a user enters the name of a task file and the error
#    handling code makes sure the file already exists and if it doesn't
#    then it will give the user to re-enter the name of the file they want loaded.
#
#----------------------------------------------------------------------#
while(True):
    taskfile = input("What is the name of the task file you want to edit?: ")
    try:
        with open("C:\\_PythonClass\Assignment07\\" + taskfile) as file:
            read_data = file.read()
    except FileNotFoundError as fnf_error:
        print(fnf_error)
        strChoice = str(input("Do you want to try entering the file name again? [y/n] - "))
    else:
        print("Your file '"+taskfile+"' has successfully been loaded.")
        break
    if (strChoice.strip().lower() != 'y'):
        print ("")
        print("WARNING..No file has not been loaded.")
        break

