#----------------------------------------------------------------------#
# Title: Error Handling Script
# Dev: JPatten
# Date Feb 22, 2019
# ChangeLog:
# Purpose:  This program demonstrates how to pickle and unpickle a dictionary file.
#
#----------------------------------------------------------------------#

import pickle
#example_dict = {1:"efewf",2:"efw",3:"fgwr"}
#pickle_out = open("dict.pickle","wb")
#pickle.dump(example_dict, pickle_out)
#pickle_out.close()

pickle_in = open("dict.pickle","rb")
example_dict = pickle.load(pickle_in)
print(example_dict)
